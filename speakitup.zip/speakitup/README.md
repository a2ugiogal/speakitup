要抒啦！
===
__:mega:上網抒發，最怕遇到酸民來搗亂！<br>
只想聽到自己想聽的話？那就上「要抒啦！」論壇，生活的苦悶~要抒啦！__

&nbsp; &nbsp; &nbsp; &nbsp;作為「台北科技大學Java & Android人才養成班」第十三屆學員從0開始，歷經六個月密集訓練後的成果作品。抱持科技人對人文關懷的使命，「要抒啦！」是個能夠預期回應溫度的論壇空間，想被拍拍誇誇來碗心靈雞湯的你請右轉「天使版:innocent:」，想來碗惡魔毒湯被罵醒或和鄉民講講幹話的你左轉「惡魔版:smiling_imp:」。無論感情、生活、工作、時事都可以聊，還附設購物商城「要買啦！:money_with_wings:」，各種新奇有趣的商品都在這裡。
## 本站首頁
:construction_worker:努力開發中...先看看Logo！
<div align=center><img width="250" height="250" src="https://i.imgur.com/YcAYvay.png"></div>

## 開發人員
>   曾品睿(國立台北大學應用外語系)
>> * 前段刻起來~

>   詹婷伃(國立中央大學數學系)
>> * 萬能的女神

>   孫于婷(國立中央大學數學系)
>> * 口ㄞ小尖兵

>   劉昱廷(世新大學社會心理學系)
>> * 浴火重生放馬過來

>   謝榮駿(高級繪圖工程師)
>> * 安卓明日之星

>   彭淳義(高級繪圖工程師)
>> * 電商請找我

>   蔡泓哲(龍華科技大學電機工程系)
>> * 八萬五撈起來~

>   張孟群(高級客服工程師)
>> * 大家的靈魂伴侶

## 開發技術與使用工具
Java | JDBC | JSP | Spring MVC | Hirbernate | Javascript | jQuery | AJAX | CSS3 | HTML | MySQL | Git | Bootstrap | Tomcat
<i class="fab fa-html5"></i>
<i class="fab fa-css3-alt"></i>
<i class="fab fa-js-square"></i>
<i class="fab fa-java"></i>

## 首次訪問

1. 拜訪我們的首頁。
2. 選擇天使版/惡魔版。
3. 如果想發表/回應文章，請登入會員。
4. 如果你錢太多，購物！


開發進度
---
- [x] 前期規劃
- [x] 會員系統
- [x] 商城系統
- [x] 論壇系統
- [ ] 後台系統
- [ ] 測試階段
- [ ] 正式發表
> 了解我們的開發行事曆 : https://calendar.google.com/calendar?cid=Y2Fycm90NzcxMkBnbWFpbC5jb20



###### tags: `要抒啦` `論壇` `商城` `紓壓` `天使版` `惡魔版` `軟體工程師` `人才` `八萬五` `水溝` `我就爛`
