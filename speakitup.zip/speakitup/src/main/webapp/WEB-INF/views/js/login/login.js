//function doFitst(){
//	loginBtn = document.getElementById('loginBtn');
//	inputmemberId = document.getElementById('inputmemberId');
//	inputPassword = document.getElementById('inputPassword');
//	idEmptyError = document.getElementById('idEmptyError');
//	passwordEmptyError = document.getElementById('passwordEmptyError');
//	
//	loginBtn.addEventListener('click',checkLogin)
//}
//function checkLogin(){
//	xhr = new XMLHttpRequest();
//	xhr.open
//	(
//	"POST",
//	"/speakitup/login/checkUserPassword/{memberId}/{password}
//	)
//}
//
//window.addEventListener('load',doFirst);